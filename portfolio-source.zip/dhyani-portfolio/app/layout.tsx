import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'Dhyani Patel — Digital, AI & Business',
  description:
    'Dhyani Patel. Manager, Thrumline. Explore a skillset across digital marketing, AI, creative technology, and business.',
  icons: { icon: '/favicon.svg' },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link
          rel="preload"
          href="/fonts/manrope-latin.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <link
          rel="preload"
          href="/fonts/instrument-serif-italic.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
