'use client';

import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { Tabs as TabsPrimitive } from '@base-ui/react/tabs';
import { TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { profile, skillGroups, credentials } from './portfolio-data';

const navigation = [
  ['About', 'about'],
  ['Skills', 'skills'],
  ['Experience', 'experience'],
  ['Certifications', 'certifications'],
];
const contactLinks = [
  {
    label: 'Email',
    value: profile.contacts.email,
    href: `mailto:${profile.contacts.email}`,
  },
  {
    label: 'LinkedIn',
    value: profile.contacts.linkedin,
    href: profile.contacts.linkedin,
  },
  {
    label: 'Instagram',
    value: profile.contacts.instagram,
    href: profile.contacts.instagram,
  },
].filter((link) => link.value.trim());

function Arrow({ direction = 'up' }: { direction?: 'up' | 'down' }) {
  return (
    <span aria-hidden="true" className="arrow">
      {direction === 'down' ? '↓' : '↗'}
    </span>
  );
}

function Monogram({ motion }: { motion: boolean }) {
  const objectRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef(0);
  useEffect(() => () => cancelAnimationFrame(frameRef.current), []);
  function move(event: PointerEvent<HTMLDivElement>) {
    if (!motion || event.pointerType !== 'mouse') return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    cancelAnimationFrame(frameRef.current);
    frameRef.current = requestAnimationFrame(() => {
      objectRef.current?.style.setProperty('--rotate-x', `${-y * 12}deg`);
      objectRef.current?.style.setProperty('--rotate-y', `${x * 12}deg`);
    });
  }
  function reset() {
    cancelAnimationFrame(frameRef.current);
    objectRef.current?.style.setProperty('--rotate-x', '0deg');
    objectRef.current?.style.setProperty('--rotate-y', '0deg');
  }
  return (
    <div
      className="identity-stage"
      aria-hidden="true"
      onPointerMove={move}
      onPointerLeave={reset}
    >
      <div className="identity-object" ref={objectRef}>
        <div className="identity-coordinate">
          <span>DP — PERSONAL INDEX</span>
          <span>01</span>
        </div>
        <div className="monogram">
          <span>d</span>
          <span>p</span>
        </div>
        <div className="identity-foot">
          <span>
            A MULTIDISCIPLINARY
            <br />
            PERSPECTIVE
          </span>
          <Arrow />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const [enhanced, setEnhanced] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState('marketing');
  const [motion, setMotion] = useState(true);
  const rootRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    setEnhanced(true);
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setMotion(!preference.matches);
    update();
    preference.addEventListener('change', update);
    return () => preference.removeEventListener('change', update);
  }, []);
  useEffect(() => {
    const elements = rootRef.current?.querySelectorAll<HTMLElement>('.reveal');
    if (!motion || !('IntersectionObserver' in window)) {
      elements?.forEach((el) => el.classList.remove('reveal-ready'));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-seen');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.06 },
    );
    elements?.forEach((el) => {
      el.classList.add('reveal-ready');
      observer.observe(el);
    });
    return () => {
      observer.disconnect();
      elements?.forEach((el) => el.classList.remove('reveal-ready'));
    };
  }, [motion]);
  useEffect(() => {
    const query = window.matchMedia('(min-width: 768px)');
    const close = () => {
      if (query.matches) setMenuOpen(false);
    };
    query.addEventListener('change', close);
    return () => query.removeEventListener('change', close);
  }, []);

  return (
    <div
      ref={rootRef}
      className={`portfolio ${motion ? 'motion-enabled' : 'motion-paused'}${enhanced ? ' is-enhanced' : ''}`}
    >
      <div className="arrival" aria-hidden="true">
        <span>
          DHYANI <em>Patel.</em>
        </span>
        <i />
      </div>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <a
          className="wordmark"
          href="#top"
          aria-label="Dhyani Patel, back to top"
        >
          d<span>/</span>p.
        </a>
        <span className="header-note">THE PERSONAL PORTFOLIO</span>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navigation.map(([label, id]) => (
            <a key={id} href={`#${id}`}>
              {label}
            </a>
          ))}
          {contactLinks.length > 0 && (
            <a href="#contact">
              Contact <Arrow />
            </a>
          )}
        </nav>
        <details className="native-menu html-fallback">
          <summary>
            Menu <span aria-hidden="true">＋</span>
          </summary>
          <nav aria-label="Mobile navigation">
            {navigation.map(([label, id]) => (
              <a key={id} href={`#${id}`}>
                {label} <Arrow />
              </a>
            ))}
            {contactLinks.length > 0 && (
              <a href="#contact">
                Contact <Arrow />
              </a>
            )}
          </nav>
        </details>
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger className="menu-trigger requires-js">
            Menu <span aria-hidden="true">＋</span>
          </SheetTrigger>
          <SheetContent className="mobile-menu" side="right">
            <SheetTitle className="menu-title">Dhyani Patel</SheetTitle>
            <SheetDescription className="menu-description">
              Digital / AI / Business
            </SheetDescription>
            <nav aria-label="Mobile navigation">
              {navigation.map(([label, id], index) => (
                <SheetClose
                  nativeButton={false}
                  key={id}
                  render={<a href={`#${id}`} />}
                >
                  <span className="menu-index">0{index + 1}</span>
                  {label}
                  <Arrow />
                </SheetClose>
              ))}
              {contactLinks.length > 0 && (
                <SheetClose nativeButton={false} render={<a href="#contact" />}>
                  Contact <Arrow />
                </SheetClose>
              )}
            </nav>
            <span className="menu-bottom">MANAGER, THRUMLINE</span>
          </SheetContent>
        </Sheet>
      </header>
      <main id="main" tabIndex={-1}>
        <section className="hero page-pad" id="top" aria-labelledby="name">
          <div className="eyebrow hero-eyebrow">
            <span>DIGITAL / AI / BUSINESS</span>
            <span>MANAGER, THRUMLINE</span>
          </div>
          <div className="hero-grid">
            <h1 id="name" aria-label="Dhyani Patel">
              <span>DHYANI</span>
              <span>
                PATEL<span className="name-dot">.</span>
              </span>
            </h1>
            <Monogram motion={motion} />
          </div>
          <div className="hero-bottom">
            <p className="hero-statement">
              A digital mind.
              <br />
              <em>A business perspective.</em>
            </p>
            <div className="hero-summary">
              <p>
                Working across marketing, AI, technology, and the business
                behind it all.
              </p>
              <a className="text-link" href="#skills">
                Explore my skillset <Arrow direction="down" />
              </a>
            </div>
            <span className="scroll-note" aria-hidden="true">
              SCROLL TO EXPLORE ↓
            </span>
          </div>
        </section>

        <section
          id="about"
          className="about-section page-pad"
          aria-labelledby="about-heading"
        >
          <div className="section-top">
            <span className="eyebrow">01 / ABOUT</span>
            <span className="eyebrow secondary-label">
              THE PERSON BEHIND THE NAME
            </span>
          </div>
          <div className="about-layout reveal">
            <div className="about-aside">
              <span className="tiny-monogram" aria-hidden="true">
                d/p.
              </span>
              <span>
                DHYANI PATEL
                <br />
                MANAGER, THRUMLINE
              </span>
            </div>
            <div className="about-copy">
              <h2 id="about-heading">
                Different disciplines.
                <br />
                <em>
                  One connected
                  <br className="desktop-break" /> perspective.
                </em>
              </h2>
              <div className="about-paragraphs">
                <p>
                  I’m Dhyani, Manager at Thrumline. My professional world brings
                  together digital marketing, AI tools, creative technology, and
                  business management.
                </p>
                <p>
                  From communication and content to web tools and operations,
                  this is the range I work across.
                </p>
              </div>
            </div>
          </div>
          <div
            className="discipline-strip reveal"
            aria-label="Core disciplines"
          >
            <span>Marketing</span>
            <i aria-hidden="true">/</i>
            <span>AI</span>
            <i aria-hidden="true">/</i>
            <span>Technology</span>
            <i aria-hidden="true">/</i>
            <span>Business</span>
          </div>
        </section>

        <section
          id="skills"
          className="skills-section page-pad"
          aria-labelledby="skills-heading"
        >
          <div className="section-top">
            <span className="eyebrow">02 / WHAT I WORK ACROSS</span>
            <span className="eyebrow secondary-label">
              A CONNECTED SKILLSET
            </span>
          </div>
          <div className="section-heading reveal">
            <h2 id="skills-heading">
              The range.
              <br />
              <em>And the detail.</em>
            </h2>
            <p>
              Marketing, technology, and business. Explore the skills and tools
              that connect them.
              <br />
              <span className="knowledge-note">
                Skill areas & working knowledge.
              </span>
            </p>
          </div>
          <TabsPrimitive.Root
            data-slot="tabs"
            className="skills-explorer requires-js"
            orientation="vertical"
            value={selectedSkill}
            onValueChange={(value) => setSelectedSkill(String(value))}
          >
            <label className="mobile-skill-select">
              <span className="eyebrow">EXPLORE AN AREA</span>
              <select
                aria-label="Skill category"
                value={selectedSkill}
                onChange={(event) => setSelectedSkill(event.target.value)}
              >
                {skillGroups.map((group) => (
                  <option key={group.id} value={group.id}>
                    {group.title}
                  </option>
                ))}
              </select>
              <span className="select-arrow" aria-hidden="true">
                ↓
              </span>
            </label>
            <TabsList
              className="skill-navigation"
              aria-label="Skill categories"
            >
              {skillGroups.map((group, index) => (
                <TabsTrigger
                  className="skill-trigger"
                  key={group.id}
                  value={group.id}
                >
                  <span className="skill-number">0{index + 1}</span>
                  <span>{group.title}</span>
                  <Arrow />
                </TabsTrigger>
              ))}
            </TabsList>
            <div className="skill-panels">
              {skillGroups.map((group, index) => (
                <TabsContent
                  data-current={selectedSkill === group.id}
                  className={`skill-panel panel-${group.id}`}
                  key={group.id}
                  value={group.id}
                >
                  <div className="skill-panel-top">
                    <span className="eyebrow">{group.lens}</span>
                    <span className="eyebrow">0{index + 1} / 07</span>
                  </div>
                  <h3 className="skill-word">
                    <em>{group.word}</em>
                  </h3>
                  <p className="skill-description">{group.description}</p>
                  <ul className="skill-list">
                    {group.skills.map((skill) => (
                      <li key={skill}>{skill}</li>
                    ))}
                  </ul>
                </TabsContent>
              ))}
            </div>
          </TabsPrimitive.Root>
          <div className="native-skills html-fallback">
            {skillGroups.map((group, index) => (
              <details key={group.id} open={index === 0}>
                <summary>
                  <span className="eyebrow">0{index + 1}</span>
                  {group.fullTitle}
                  <span className="native-plus" aria-hidden="true">
                    ＋
                  </span>
                </summary>
                <div className={`native-skill-content panel-${group.id}`}>
                  <p className="skill-description">{group.description}</p>
                  <ul className="skill-list">
                    {group.skills.map((skill) => (
                      <li key={skill}>{skill}</li>
                    ))}
                  </ul>
                </div>
              </details>
            ))}
          </div>
        </section>

        <section
          id="experience"
          className="experience-section page-pad"
          aria-labelledby="experience-heading"
        >
          <div className="section-top">
            <span className="eyebrow">03 / EXPERIENCE</span>
            <span className="eyebrow secondary-label">
              THE PROFESSIONAL CHAPTER
            </span>
          </div>
          <div className="experience-layout reveal">
            <h2 id="experience-heading">
              In the
              <br />
              <em>business of digital.</em>
            </h2>
            <ol className="experience-timeline">
              <li>
                <div className="timeline-meta">
                  <i className="status-dot" />
                  <span className="eyebrow">CURRENT ROLE</span>
                </div>
                <h3>
                  Manager<span className="role-comma">,</span>
                  <br />
                  <span className="company-name">Thrumline</span>
                </h3>
                <div className="role-label">
                  <span>PROFESSIONAL ASSOCIATION</span>
                  <span aria-hidden="true">↗</span>
                </div>
              </li>
            </ol>
          </div>
        </section>

        <section
          id="certifications"
          className="credentials-section page-pad"
          aria-labelledby="credentials-heading"
        >
          <div className="section-top">
            <span className="eyebrow">04 / CERTIFICATIONS</span>
            <span className="eyebrow secondary-label">
              LEARNING, DOCUMENTED
            </span>
          </div>
          <div className="section-heading reveal">
            <h2 id="credentials-heading">
              Learning,
              <br />
              <em>documented.</em>
            </h2>
            <p>AI learning through be10x and Anthropic.</p>
          </div>
          <div className="credential-list">
            {credentials.map((credential, index) => (
              <article className="credential-row reveal" key={credential.id}>
                <span className="credential-number" aria-hidden="true">
                  0{index + 1}
                </span>
                <div className="credential-provider">
                  <span className={`provider-name provider-${credential.id}`}>
                    {credential.provider}
                  </span>
                  <span className="credential-type">{credential.type}</span>
                </div>
                <div className="credential-copy">
                  <h3>{credential.title}</h3>
                  <p>{credential.summary}</p>
                  {credential.issued && (
                    <time dateTime={credential.dateTime}>
                      {credential.issued}
                    </time>
                  )}
                  <details className="native-credential html-fallback">
                    <summary>
                      View details <Arrow />
                    </summary>
                    <p>{credential.details}</p>
                    <p>Recipient: {credential.recipient}</p>
                    {credential.topics.length > 0 && (
                      <ul className="credential-topics">
                        {credential.topics.map((topic) => (
                          <li key={topic}>{topic}</li>
                        ))}
                      </ul>
                    )}
                  </details>
                </div>
                <Dialog>
                  <DialogTrigger
                    className="credential-open requires-js"
                    aria-label={`View ${credential.title} details`}
                  >
                    <span>View details</span>
                    <Arrow />
                  </DialogTrigger>
                  <DialogContent className="credential-dialog">
                    <span className="eyebrow">
                      {credential.provider} / {credential.type}
                    </span>
                    <DialogTitle className="credential-dialog-title">
                      {credential.title}
                    </DialogTitle>
                    <DialogDescription className="credential-dialog-description">
                      {credential.details}
                    </DialogDescription>
                    <dl className="credential-facts">
                      <div>
                        <dt>Recipient</dt>
                        <dd>{credential.recipient}</dd>
                      </div>
                      <div>
                        <dt>Provider</dt>
                        <dd>{credential.provider}</dd>
                      </div>
                      {credential.issued && (
                        <div>
                          <dt>Issued</dt>
                          <dd>
                            <time dateTime={credential.dateTime}>
                              {credential.issued}
                            </time>
                          </dd>
                        </div>
                      )}
                    </dl>
                    {credential.topics.length > 0 && (
                      <ul className="credential-topics">
                        {credential.topics.map((topic) => (
                          <li key={topic}>{topic}</li>
                        ))}
                      </ul>
                    )}
                  </DialogContent>
                </Dialog>
              </article>
            ))}
          </div>
        </section>

        {contactLinks.length > 0 && (
          <section
            id="contact"
            className="contact-section page-pad"
            aria-labelledby="contact-heading"
          >
            <span className="eyebrow">LET’S CONNECT</span>
            <h2 id="contact-heading">
              A conversation.
              <br />
              <em>A new possibility.</em>
            </h2>
            <div className="contact-links">
              {contactLinks.map((link) => (
                <a
                  key={link.label}
                  className="text-link"
                  href={link.href}
                  target={link.label === 'Email' ? undefined : '_blank'}
                  rel={
                    link.label === 'Email' ? undefined : 'noopener noreferrer'
                  }
                >
                  {link.label}
                  <Arrow />
                </a>
              ))}
            </div>
          </section>
        )}
      </main>
      <footer className="site-footer page-pad">
        <div className="footer-top">
          <span className="eyebrow">DIGITAL / AI / MARKETING / BUSINESS</span>
          <a className="back-top" href="#top">
            Back to top <Arrow direction="up" />
          </a>
        </div>
        <div className="footer-name" aria-hidden="true">
          DHYANI<em>Patel.</em>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Dhyani Patel</span>
          <span className="footer-signoff">
            A digital mind. A business perspective.
          </span>
          <button
            className="motion-toggle requires-js"
            type="button"
            onClick={() => setMotion(!motion)}
            aria-pressed={!motion}
          >
            <span aria-hidden="true">{motion ? 'Ⅱ' : '▷'}</span>{' '}
            {motion ? 'Pause motion' : 'Resume motion'}
          </button>
        </div>
      </footer>
    </div>
  );
}
