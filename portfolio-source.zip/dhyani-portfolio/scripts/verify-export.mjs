import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';

const root = resolve('dist/client');
const basePath = process.env.PORTFOLIO_BASE_PATH || '';
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const escapeHtml = (value) =>
  value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#x27;');
const localFile = (url) => {
  let assetPath = url.split(/[?#]/)[0];
  if (basePath && assetPath.startsWith(`${basePath}/`)) {
    assetPath = assetPath.slice(basePath.length);
  }
  const path = resolve(root, assetPath.replace(/^\//, ''));
  assert(path.startsWith(`${root}/`), `Asset outside export: ${url}`);
  return path;
};

assert.equal(
  (html.match(/<h1\b/g) || []).length,
  1,
  'Exactly one H1 is required',
);
assert(!/href="(?:|#)"/.test(html), 'Empty links are not allowed');
for (const [, id] of html.matchAll(/href="#([^"]+)"/g)) {
  assert(html.includes(`id="${id}"`), `Missing anchor: ${id}`);
}
const data = await readFile('app/portfolio-data.ts', 'utf8');
const skills = [...data.matchAll(/skills: \[([\s\S]*?)\]/g)].flatMap(
  ([, list]) => [...list.matchAll(/'([^']+)'/g)].map(([, value]) => value),
);
assert.equal(
  skills.length,
  73,
  'Review any change to the approved skill inventory',
);
for (const skill of skills)
  assert(html.includes(escapeHtml(skill)), `Missing HTML skill: ${skill}`);
for (const fact of [
  'Dhyani Patel',
  'Thrumline',
  'AI Tools & Claude Workshop',
  'Claude 101',
  'August 16, 2026',
]) {
  assert(html.includes(escapeHtml(fact)), `Missing factual content: ${fact}`);
}
assert(
  html.includes('native-skills html-fallback'),
  'Native HTML skill fallback is required',
);
assert(
  html.includes('native-menu html-fallback'),
  'Native HTML navigation is required',
);
assert.equal(
  (html.match(/native-credential html-fallback/g) || []).length,
  2,
  'Both certifications require native HTML details',
);

for (const [, reference] of html.matchAll(/(?:href|src)="(\/[^\"]+)"/g)) {
  assert(
    (await stat(localFile(reference))).isFile(),
    `Missing asset: ${reference}`,
  );
}
const cssLinks = [
  ...html.matchAll(/<link\b(?=[^>]*rel="stylesheet")[^>]*>/g),
].map(([tag]) => tag);
assert(cssLinks.length > 0, 'Stylesheet is required');
let css = '';
for (const tag of cssLinks) {
  const url = tag.match(/href="([^"]+)"/)[1];
  css += await readFile(localFile(url), 'utf8');
}
for (const [, , url] of css.matchAll(/url\((['"]?)([^)'"\s]+)\1\)/g)) {
  if (url.startsWith('data:') || url.startsWith('#')) continue;
  assert(url.startsWith('/'), `Unexpected nonlocal stylesheet asset: ${url}`);
  await stat(localFile(url));
  const type = extname(url) === '.woff2' ? 'font/woff2' : 'image/svg+xml';
  const bytes = await readFile(localFile(url));
  css = css.replaceAll(url, `data:${type};base64,${bytes.toString('base64')}`);
}
const favicon = await readFile(resolve(root, 'favicon.svg'));
let portable = html
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/g, '')
  .replace(/<link\b[^>]*>/g, (tag) => {
    if (tag.includes('rel="icon"'))
      return `<link rel="icon" href="data:image/svg+xml;base64,${favicon.toString('base64')}">`;
    return '';
  })
  .replace(
    '</head>',
    `<meta name="robots" content="noindex"><style>${css}</style></head>`,
  );
assert(
  !/<script\b|(?:src|href)="\//.test(portable),
  'Portable file must not depend on scripts or external files',
);
assert(
  !/url\((['"]?)(?:https?:|\/)/.test(portable),
  'Portable file must embed styling assets',
);
await writeFile(resolve(root, 'dhyani-patel.html'), portable);

async function filesIn(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  return (
    await Promise.all(
      entries.map((entry) =>
        entry.isDirectory()
          ? filesIn(resolve(directory, entry.name))
          : resolve(directory, entry.name),
      ),
    )
  ).flat();
}
const files = await filesIn(resolve(root, '_next/static'));
const jsFiles = files.filter((file) => file.endsWith('.js'));
let scriptBytes = 0;
for (const file of jsFiles) {
  const buffer = await readFile(file);
  scriptBytes += gzipSync(buffer).length;
  const source = buffer.toString();
  for (const [, reference] of source.matchAll(
    /(?:from\s*|import\s*\(|import\s*)["'](\.\/[^"']+)["']/g,
  )) {
    await stat(resolve(file, '..', reference));
  }
}
assert(
  scriptBytes < 200 * 1024,
  'Compressed JavaScript exceeded the 200 KiB budget',
);
assert(
  Buffer.byteLength(portable) < 300 * 1024,
  'Portable HTML exceeded the 300 KiB budget',
);
console.log(
  `Static export verified: ${skills.length} skills, 2 certifications, complete anchor and asset references.`,
);
console.log(
  `JavaScript: ${(scriptBytes / 1024).toFixed(1)} KiB gzip across all chunks. Portable HTML: ${(Buffer.byteLength(portable) / 1024).toFixed(1)} KiB, fully embedded.`,
);
