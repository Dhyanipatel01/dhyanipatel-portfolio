import { readdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

// This single-page export uses anchors, so only its asset URLs need a prefix.
// Keep the default root export intact for hosts that serve at the domain root.
const basePath = process.env.PORTFOLIO_BASE_PATH || '';
if (basePath) {
  assert(/^\/[a-zA-Z0-9_-]+$/.test(basePath), 'Use a single repository path');
  const root = resolve('dist/client');
  async function prefixAssets(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const file = resolve(directory, entry.name);
      if (entry.isDirectory()) {
        await prefixAssets(file);
      } else if (['.html', '.css', '.js', '.json', '.rsc'].includes(extname(file))) {
        const original = await readFile(file, 'utf8');
        const prefixed = original.replace(/\/(?:_next\/|fonts\/|favicon\.svg)/g,
          (asset) => `${basePath}${asset}`);
        if (prefixed !== original) await writeFile(file, prefixed);
      }
    }
  }
  await prefixAssets(root);
  await writeFile(resolve(root, '.nojekyll'), '');
  console.log(`Prepared static assets for ${basePath}/`);
}
