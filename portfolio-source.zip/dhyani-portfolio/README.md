# Dhyani Patel — personal portfolio

A light editorial portfolio with a D/P typographic identity, a short arrival sequence, a responsive skill index, and accessible credential dialogs.

## Content

`app/portfolio-data.ts` is the factual content source. It contains all 73 owner-requested skills, the exact Manager, Thrumline role, and the two owner-supplied certification records. Empty public contact fields are deliberately filtered out; providing values enables the contact section and its navigation links.

No personal projects, client results, founder claims, employment dates, hobbies, education, or unprovided contact details have been invented. Certificate images were not supplied or located, so the website displays accurate text records instead of simulated certificate artwork.

## Development

Use Node 22.13 or later and the existing pnpm lockfile. Run `pnpm install`, then `pnpm dev`. Production build: `pnpm build`. Type check: `pnpm exec tsc --noEmit`.

## Reliable sharing

Production uses a static HTML export in `dist/client`; page delivery requires no application server, database, or API. Native menu, skill and certification disclosures are available before hydration, when JavaScript fails, and with JavaScript disabled. Enhanced tabs, dialogs and motion controls only appear once the client has mounted. Reveal effects never leave unrevealed content permanently hidden. Fonts are local, preloaded, and have system fallbacks.

Every build validates anchor targets, referenced assets, all 73 approved skills, native fallbacks, and compressed JavaScript and portable-file size budgets. It also generates `dist/client/dhyani-patel.html`: a self-contained edition with embedded styling, fonts and favicon. This file opens offline with native HTML interactions; the hosted edition includes the enhanced tabs, dialogs and pointer motion. Do not send `index.html` by itself: that hosted entrypoint requires its companion assets.

Preview with `pnpm start`, or serve `dist/client` with any static web server. Sites hosting points to this static directory. Public sharing must use the site's public access setting; a local export alone does not change the hosted audience.

For GitHub Pages at `/dhyanipatel-portfolio/`, build with `PORTFOLIO_BASE_PATH=/dhyanipatel-portfolio pnpm build`. The build prefixes local asset URLs, verifies the resulting files, and adds `.nojekyll` so GitHub serves `_next` assets. Publish the contents of `dist/client` at the repository root. The default build continues to support domain-root hosting.

## Design and validation

Palette: ivory, charcoal text, and citron; all sections remain light. Locally hosted Manrope and Instrument Serif fonts include their OFL licenses. Motion uses finite CSS animations, IntersectionObserver, and pointer movement limited to the monogram. The system reduced-motion preference and an explicit motion control are supported.

Browser validation covered widths 320, 375, 390, 414, 768, 1024, 1440, and 1920; no page overflow, empty links, or broken anchor targets were found. All seven skill categories were exercised and their counts verified. Keyboard category navigation, mobile menu dismissal, credential details, Escape handling, focus restoration, and reduced-motion behavior were checked. Visual review corrected mobile monogram overflow, outgoing skill-panel overlap, and small text. Production build and TypeScript validation pass.

Research included Brittany Chiang (https://brittanychiang.com/), Seán Halpin (https://www.seanhalpin.xyz/), and Isabel Moranta's Behance portfolio (https://www.behance.net/gallery/122392185/Isabel-Moranta-Portfolio). These informed hierarchy and editorial principles; no layouts, copy, imagery, or personal claims were copied. Pinterest and Instagram were attempted but direct access was unavailable.
